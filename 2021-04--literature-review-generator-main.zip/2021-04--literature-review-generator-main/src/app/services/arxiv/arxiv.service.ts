import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { Paper } from 'src/app/interfaces/paper';
import {Parser} from 'xml2js'

@Injectable({
  providedIn: 'root'
})
export class ArxivService {

  createUrl(keywords: string[]) {
    const base = "https://export.arxiv.org/api/query?"
    let params = new HttpParams();

    const tempKeywords = keywords.map((element : string) => {
      element.replace(" ", "+")
      return element
    })

    params = params.set('search_query', tempKeywords.join("+OR+"));
    return base + params.toString()
  }

  async updatePapers(keywords: string[]): Promise<Paper[]>{
    if(!keywords.length){
      return [];
    }

    const url = this.createUrl(keywords)
    const source$ = this.http.get(url, { responseType: 'text' })
    const response = await firstValueFrom(source$);
    const papers : Paper[] = []
    const parser = new Parser()
    parser.parseString(response, function(err:any,res:any){
      const entries = res.feed.entry
      entries.forEach((element: any) => {
        const paper : Paper = {
          id : element.id[0],
          summary: element.summary[0],
          title: element.title[0]
        }
        papers.push(paper)
      });
    })
    return papers
  }

  constructor(
    private http: HttpClient
  ) { }
}
