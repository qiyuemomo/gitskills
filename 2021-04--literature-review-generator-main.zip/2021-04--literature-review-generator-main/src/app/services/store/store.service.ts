import { Injectable } from '@angular/core';
import { Paper } from '../..//interfaces/paper';
import { ArxivService } from '../arxiv/arxiv.service';

@Injectable({
  providedIn: 'root'
})
export class StoreService {
  keywords : string[] = []
  papers : Paper[] = []
  isLoading: Boolean = false; 

  removeKeyword(index : number){
    if(index > -1 && index < this.keywords.length){
      this.keywords.splice(index, 1);
    }
  }

  addKeyWord(value : string){
    if(value.length){
      value = value.trim()
      this.keywords.push(value)
    }
  }

  updatePapers(){
    this.isLoading = true
    this.arxiv.updatePapers(this.keywords).then((response)=>{
      this.papers = response
      this.isLoading = false
    })
  }
  
  constructor(
    public arxiv: ArxivService
    ) { }
}
