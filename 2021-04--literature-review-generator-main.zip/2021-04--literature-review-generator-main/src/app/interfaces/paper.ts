export interface Paper {
    id: string;
    title: string;
    summary: string;
}