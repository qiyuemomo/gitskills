import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoreService } from 'src/app/services/store/store.service';

@Component({
  selector: 'home-view',
  templateUrl: './home-view.component.html',
  styleUrls: ['./home-view.component.css']
})
export class HomeViewComponent implements OnInit {
  inputPlaceholder = "Enter keywords, separated by a comma"
  inputValue : string = ""

  onButtonClick(){
    if(!this.inputValue.length){
      alert("The input field is empty!")
      return;
    }

    this.storeService.keywords = this.getKeywordsFromString(this.inputValue)
    this.router.navigateByUrl('/papers');
  }

  getKeywordsFromString(text : string){
    var keywords : string[] = text.split(",")
    
    keywords = keywords.map((keyword) => {
      return keyword.trim() 
    })

    return keywords
  }


  constructor(
    private router: Router, 
    private storeService : StoreService) {
  }

  ngOnInit(): void {
  }
}
