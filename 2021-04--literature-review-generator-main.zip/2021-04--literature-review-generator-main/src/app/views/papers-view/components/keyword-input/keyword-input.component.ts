import { Component, OnInit } from '@angular/core';
import { StoreService } from 'src/app/services/store/store.service';

@Component({
  selector: 'keyword-input',
  templateUrl: './keyword-input.component.html',
  styleUrls: ['./keyword-input.component.css']
})
export class KeywordInputComponent implements OnInit {
  inputValue : string = ""

  addKeyWord(){
    this.storeService.addKeyWord(this.inputValue)
    this.inputValue = ""
  }
  
  constructor(
    public storeService : StoreService
  ) { }

  ngOnInit(): void {
  }

}
