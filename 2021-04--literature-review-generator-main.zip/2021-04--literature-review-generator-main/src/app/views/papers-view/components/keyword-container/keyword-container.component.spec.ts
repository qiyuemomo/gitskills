import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeywordContainerComponent } from './keyword-container.component';

describe('KeywordContainerComponent', () => {
  let component: KeywordContainerComponent;
  let fixture: ComponentFixture<KeywordContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeywordContainerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KeywordContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
