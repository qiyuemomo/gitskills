import { Component, OnInit } from '@angular/core';
import { StoreService } from 'src/app/services/store/store.service';

@Component({
  selector: 'keyword-container',
  templateUrl: './keyword-container.component.html',
  styleUrls: ['./keyword-container.component.css']
})
export class KeywordContainerComponent implements OnInit {

  removeKeyword(index : number){
    this.storeService.removeKeyword(index)
  }

  constructor(
    public storeService : StoreService
  ) { }

  ngOnInit(): void {
  }

}
