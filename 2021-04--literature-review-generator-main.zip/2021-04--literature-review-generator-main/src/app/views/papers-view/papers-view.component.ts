import { Component, OnInit } from '@angular/core';
import { StoreService } from 'src/app/services/store/store.service';

@Component({
  selector: 'papers-view',
  templateUrl: './papers-view.component.html',
  styleUrls: ['./papers-view.component.css']
})
export class PapersViewComponent implements OnInit {

  constructor(
    public storeService : StoreService
  ) { }

  ngOnInit(): void {
    this.storeService.updatePapers()
  }

}
