import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PapersViewComponent } from './papers-view.component';

describe('PapersViewComponent', () => {
  let component: PapersViewComponent;
  let fixture: ComponentFixture<PapersViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PapersViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PapersViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
